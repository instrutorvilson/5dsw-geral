/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package resource;

import com.google.gson.Gson;
import entity.Product;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author vilso
 */
@Path("produtos")
public class ProdutoResource {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of ProdutoResource
     */
    public ProdutoResource() {
    }

    /**
     * Retrieves representation of an instance of resource.ProdutoResource
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String getJson() {
       List<Product> produtos = new ArrayList<>();
       produtos.add(new Product("Feijão", 10, 10));
       produtos.add(new Product("Milho", 10.3f, 20));
       produtos.add(new Product("Trigo", 26.65f, 30));
       produtos.add(new Product("Cevada", 260.65f, 30));
       produtos.add(new Product("Lupulo", 16.65f, 30));
       
       Gson gson = new Gson();
       return gson.toJson(produtos);
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public String putJson(String content) {
        return content;
    }
}
